**Updated March 02, 2021**

# Campus-Network-Design
The aim of this project is to design the topology of the university network using the software Cisco Packet Tracer.

## Contributors

- [Jitendra Singh](https://github.com/jet0499)
- [Vivek Goyal](https://github.com/vivek-goyal12)

# Project Mentor:
Mr. Pankaj Kapoor

# Contacts:
Feel free to contact us if you have any further queries, at: jitendra.singh_cs18@gla.ac.in and vivek.goyal_cs18@gla.ac.in .

## Project Meeting:-
Date - 26/02/2021
Discussion - Basic project developement and the synopsis structure to be made.
Topic Covered - Wprked on synopsis starting with project
Mentor Feedback/Suggestion - Give a startup to this project , create synopsis and using the software Cisco Packet Tracer.

